class Calculator
 def summa 
 a = 1
 b = 1
 return sum = a + b
 end
end
