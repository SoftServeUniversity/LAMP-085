'''
Created on 13 april 2013

@author: vl
'''

if __name__ == '__main__':
    from application.App import App
    APP = App()
    APP.run()