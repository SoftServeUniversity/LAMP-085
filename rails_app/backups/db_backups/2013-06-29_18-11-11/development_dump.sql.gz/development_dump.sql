-- MySQL dump 10.13  Distrib 5.5.31, for debian-linux-gnu (i686)
--
-- Host: localhost    Database: auth_development
-- ------------------------------------------------------
-- Server version	5.5.31-0ubuntu0.12.10.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `homeworks`
--

DROP TABLE IF EXISTS `homeworks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `homeworks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `language` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `homeworks`
--

LOCK TABLES `homeworks` WRITE;
/*!40000 ALTER TABLE `homeworks` DISABLE KEYS */;
INSERT INTO `homeworks` (`id`, `title`, `language`, `created_at`, `updated_at`) VALUES (1,'sales.manager','ruby','2013-06-29 15:08:51','2013-06-29 15:08:51'),(2,'accounting.manager','python','2013-06-29 15:08:52','2013-06-29 15:08:52'),(3,'owner','ruby','2013-06-29 15:08:54','2013-06-29 15:08:54'),(4,'sales.representative','python','2013-06-29 15:08:55','2013-06-29 15:08:55'),(5,'assistant.sales.representative','ruby','2013-06-29 15:08:58','2013-06-29 15:08:58'),(6,'marketing.manager','python','2013-06-29 15:08:59','2013-06-29 15:08:59'),(7,'sales.representative','ruby','2013-06-29 15:09:01','2013-06-29 15:09:01'),(8,'marketing.assistant','python','2013-06-29 15:09:07','2013-06-29 15:09:07'),(9,'owner','python','2013-06-29 15:09:11','2013-06-29 15:09:11'),(10,'marketing.manager','ruby','2013-06-29 15:09:13','2013-06-29 15:09:13'),(11,'accounting.manager','ruby','2013-06-29 15:09:15','2013-06-29 15:09:15'),(12,'sales.manager','python','2013-06-29 15:09:16','2013-06-29 15:09:16'),(13,'sales.associate','python','2013-06-29 15:09:19','2013-06-29 15:09:19'),(14,'sales.agent','ruby','2013-06-29 15:09:24','2013-06-29 15:09:24'),(15,'order.administrator','python','2013-06-29 15:09:31','2013-06-29 15:09:31'),(16,'sales.agent','python','2013-06-29 15:09:32','2013-06-29 15:09:32'),(17,'marketing.assistant','ruby','2013-06-29 15:09:37','2013-06-29 15:09:37'),(18,'sales.associate','ruby','2013-06-29 15:09:54','2013-06-29 15:09:54'),(19,'assistant.sales.agent','python','2013-06-29 15:10:20','2013-06-29 15:10:20'),(20,'assistant.sales.agent','ruby','2013-06-29 15:10:53','2013-06-29 15:10:53');
/*!40000 ALTER TABLE `homeworks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reports`
--

DROP TABLE IF EXISTS `reports`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `reports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `student_id` int(11) DEFAULT NULL,
  `homework_id` int(11) DEFAULT NULL,
  `ratio` float DEFAULT NULL,
  `quality` float DEFAULT NULL,
  `time` float DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=93 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reports`
--

LOCK TABLES `reports` WRITE;
/*!40000 ALTER TABLE `reports` DISABLE KEYS */;
INSERT INTO `reports` (`id`, `student_id`, `homework_id`, `ratio`, `quality`, `time`, `created_at`, `updated_at`) VALUES (1,1,1,100,59.09,1.55,'2013-06-29 15:08:51','2013-06-29 15:08:51'),(2,2,2,100,50,0.42,'2013-06-29 15:08:52','2013-06-29 15:08:52'),(3,1,3,100,59.09,1.56,'2013-06-29 15:08:54','2013-06-29 15:08:54'),(4,3,4,100,50,0.43,'2013-06-29 15:08:55','2013-06-29 15:08:55'),(5,4,4,100,50,0.41,'2013-06-29 15:08:56','2013-06-29 15:08:56'),(6,5,5,100,59.09,1.57,'2013-06-29 15:08:58','2013-06-29 15:08:58'),(7,6,6,100,50,0.43,'2013-06-29 15:08:59','2013-06-29 15:08:59'),(8,7,7,100,59.09,1.56,'2013-06-29 15:09:01','2013-06-29 15:09:01'),(9,8,3,100,59.09,1.7,'2013-06-29 15:09:03','2013-06-29 15:09:03'),(10,9,6,100,50,0.43,'2013-06-29 15:09:04','2013-06-29 15:09:04'),(11,10,6,100,50,0.42,'2013-06-29 15:09:05','2013-06-29 15:09:05'),(12,11,3,100,59.09,1.58,'2013-06-29 15:09:07','2013-06-29 15:09:07'),(13,12,8,100,50,0.45,'2013-06-29 15:09:07','2013-06-29 15:09:07'),(14,5,7,100,59.09,1.59,'2013-06-29 15:09:09','2013-06-29 15:09:09'),(15,6,4,100,50,0.45,'2013-06-29 15:09:10','2013-06-29 15:09:10'),(16,13,9,100,50,0.45,'2013-06-29 15:09:11','2013-06-29 15:09:11'),(17,14,10,100,59.09,1.62,'2013-06-29 15:09:13','2013-06-29 15:09:13'),(18,15,11,100,59.09,1.63,'2013-06-29 15:09:15','2013-06-29 15:09:15'),(19,16,12,100,50,0.44,'2013-06-29 15:09:16','2013-06-29 15:09:16'),(20,17,6,100,50,0.42,'2013-06-29 15:09:17','2013-06-29 15:09:17'),(21,5,11,100,59.09,1.7,'2013-06-29 15:09:18','2013-06-29 15:09:18'),(22,10,13,100,50,0.42,'2013-06-29 15:09:19','2013-06-29 15:09:19'),(23,18,4,100,50,0.45,'2013-06-29 15:09:20','2013-06-29 15:09:20'),(24,6,11,100,59.09,1.81,'2013-06-29 15:09:22','2013-06-29 15:09:22'),(25,19,14,100,59.09,1.65,'2013-06-29 15:09:24','2013-06-29 15:09:24'),(26,20,9,100,50,0.41,'2013-06-29 15:09:25','2013-06-29 15:09:25'),(27,21,3,100,59.09,1.57,'2013-06-29 15:09:27','2013-06-29 15:09:27'),(28,22,12,100,50,0.44,'2013-06-29 15:09:28','2013-06-29 15:09:28'),(29,11,2,100,50,0.45,'2013-06-29 15:09:28','2013-06-29 15:09:28'),(30,23,7,100,59.09,1.56,'2013-06-29 15:09:30','2013-06-29 15:09:30'),(31,4,15,100,50,0.45,'2013-06-29 15:09:31','2013-06-29 15:09:31'),(32,24,4,100,50,0.43,'2013-06-29 15:09:32','2013-06-29 15:09:32'),(33,20,16,100,50,0.46,'2013-06-29 15:09:33','2013-06-29 15:09:33'),(34,25,9,100,50,0.46,'2013-06-29 15:09:33','2013-06-29 15:09:33'),(35,26,3,100,59.09,1.67,'2013-06-29 15:09:35','2013-06-29 15:09:35'),(36,1,17,100,59.09,1.61,'2013-06-29 15:09:37','2013-06-29 15:09:37'),(37,16,2,100,50,0.44,'2013-06-29 15:09:38','2013-06-29 15:09:38'),(38,27,12,100,50,0.46,'2013-06-29 15:09:39','2013-06-29 15:09:39'),(39,7,11,100,59.09,1.59,'2013-06-29 15:09:41','2013-06-29 15:09:41'),(40,28,13,100,50,0.43,'2013-06-29 15:09:41','2013-06-29 15:09:41'),(41,29,4,100,50,0.43,'2013-06-29 15:09:42','2013-06-29 15:09:42'),(42,30,17,100,59.09,1.58,'2013-06-29 15:09:44','2013-06-29 15:09:44'),(43,11,1,100,59.09,1.63,'2013-06-29 15:09:46','2013-06-29 15:09:46'),(44,31,9,100,50,0.45,'2013-06-29 15:09:47','2013-06-29 15:09:47'),(45,6,9,100,50,0.45,'2013-06-29 15:09:48','2013-06-29 15:09:48'),(46,32,6,100,50,0.44,'2013-06-29 15:09:48','2013-06-29 15:09:48'),(47,33,7,100,59.09,1.87,'2013-06-29 15:09:51','2013-06-29 15:09:51'),(48,12,6,100,50,0.44,'2013-06-29 15:09:51','2013-06-29 15:09:51'),(49,34,6,100,50,0.44,'2013-06-29 15:09:52','2013-06-29 15:09:52'),(50,35,18,100,59.09,1.59,'2013-06-29 15:09:54','2013-06-29 15:09:54'),(51,36,17,100,59.09,1.63,'2013-06-29 15:09:56','2013-06-29 15:09:56'),(52,37,18,100,59.09,1.62,'2013-06-29 15:09:58','2013-06-29 15:09:58'),(53,38,1,100,59.09,1.59,'2013-06-29 15:10:00','2013-06-29 15:10:00'),(54,16,8,100,50,0.47,'2013-06-29 15:10:01','2013-06-29 15:10:01'),(55,37,1,100,59.09,1.59,'2013-06-29 15:10:03','2013-06-29 15:10:03'),(56,28,4,100,50,0.44,'2013-06-29 15:10:03','2013-06-29 15:10:03'),(57,39,1,100,59.09,1.62,'2013-06-29 15:10:05','2013-06-29 15:10:05'),(58,38,3,100,59.09,1.64,'2013-06-29 15:10:07','2013-06-29 15:10:07'),(59,40,4,100,50,0.61,'2013-06-29 15:10:08','2013-06-29 15:10:08'),(60,35,14,100,59.09,1.61,'2013-06-29 15:10:10','2013-06-29 15:10:10'),(61,38,7,100,59.09,1.59,'2013-06-29 15:10:12','2013-06-29 15:10:12'),(62,18,13,100,50,0.44,'2013-06-29 15:10:13','2013-06-29 15:10:13'),(63,41,3,100,59.09,1.59,'2013-06-29 15:10:14','2013-06-29 15:10:14'),(64,17,16,100,50,0.43,'2013-06-29 15:10:15','2013-06-29 15:10:15'),(65,39,7,100,59.09,1.56,'2013-06-29 15:10:17','2013-06-29 15:10:17'),(66,11,4,100,50,0.44,'2013-06-29 15:10:18','2013-06-29 15:10:18'),(67,33,11,100,59.09,1.59,'2013-06-29 15:10:20','2013-06-29 15:10:20'),(68,42,19,100,50,0.43,'2013-06-29 15:10:20','2013-06-29 15:10:20'),(69,34,9,100,50,0.44,'2013-06-29 15:10:21','2013-06-29 15:10:21'),(70,3,2,100,50,0.44,'2013-06-29 15:10:22','2013-06-29 15:10:22'),(71,19,17,100,59.09,1.64,'2013-06-29 15:10:24','2013-06-29 15:10:24'),(72,36,10,100,59.09,1.85,'2013-06-29 15:10:26','2013-06-29 15:10:26'),(73,15,1,100,59.09,1.58,'2013-06-29 15:10:28','2013-06-29 15:10:28'),(74,43,1,100,59.09,1.86,'2013-06-29 15:10:30','2013-06-29 15:10:30'),(75,41,11,100,59.09,1.62,'2013-06-29 15:10:32','2013-06-29 15:10:32'),(76,20,15,100,50,0.44,'2013-06-29 15:10:32','2013-06-29 15:10:32'),(77,44,9,100,50,0.44,'2013-06-29 15:10:33','2013-06-29 15:10:33'),(78,26,10,100,59.09,1.63,'2013-06-29 15:10:35','2013-06-29 15:10:35'),(79,11,10,100,59.09,1.64,'2013-06-29 15:10:37','2013-06-29 15:10:37'),(80,1,11,100,59.09,1.6,'2013-06-29 15:10:39','2013-06-29 15:10:39'),(81,24,13,100,50,0.43,'2013-06-29 15:10:40','2013-06-29 15:10:40'),(82,35,17,100,59.09,1.61,'2013-06-29 15:10:42','2013-06-29 15:10:42'),(83,40,9,100,50,0.44,'2013-06-29 15:10:42','2013-06-29 15:10:42'),(84,32,12,100,50,0.43,'2013-06-29 15:10:43','2013-06-29 15:10:43'),(85,45,14,100,59.09,1.61,'2013-06-29 15:10:45','2013-06-29 15:10:45'),(86,39,18,100,59.09,1.62,'2013-06-29 15:10:47','2013-06-29 15:10:47'),(87,24,6,100,50,0.43,'2013-06-29 15:10:48','2013-06-29 15:10:48'),(88,29,9,100,50,0.44,'2013-06-29 15:10:48','2013-06-29 15:10:48'),(89,46,3,100,59.09,1.63,'2013-06-29 15:10:51','2013-06-29 15:10:51'),(90,37,20,100,59.09,1.56,'2013-06-29 15:10:53','2013-06-29 15:10:53'),(91,22,4,100,50,0.44,'2013-06-29 15:10:54','2013-06-29 15:10:54'),(92,41,7,100,59.09,1.63,'2013-06-29 15:10:56','2013-06-29 15:10:56');
/*!40000 ALTER TABLE `reports` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `schema_migrations`
--

DROP TABLE IF EXISTS `schema_migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `schema_migrations` (
  `version` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  UNIQUE KEY `unique_schema_migrations` (`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `schema_migrations`
--

LOCK TABLES `schema_migrations` WRITE;
/*!40000 ALTER TABLE `schema_migrations` DISABLE KEYS */;
INSERT INTO `schema_migrations` (`version`) VALUES ('20130529091028'),('20130529091447'),('20130529091845'),('20130530051123');
/*!40000 ALTER TABLE `schema_migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `students`
--

DROP TABLE IF EXISTS `students`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `students` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=47 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `students`
--

LOCK TABLES `students` WRITE;
/*!40000 ALTER TABLE `students` DISABLE KEYS */;
INSERT INTO `students` (`id`, `name`, `created_at`, `updated_at`) VALUES (1,'matti.karttunen','2013-06-29 15:08:51','2013-06-29 15:08:51'),(2,'thomas.hardy','2013-06-29 15:08:52','2013-06-29 15:08:52'),(3,'helen.bennett','2013-06-29 15:08:55','2013-06-29 15:08:55'),(4,'andriy.padun','2013-06-29 15:08:56','2013-06-29 15:08:56'),(5,'simon.crowther','2013-06-29 15:08:58','2013-06-29 15:08:58'),(6,'pavlo.petryk','2013-06-29 15:08:58','2013-06-29 15:08:58'),(7,'felipe.izquierdo','2013-06-29 15:09:01','2013-06-29 15:09:01'),(8,'liz.nixon','2013-06-29 15:09:03','2013-06-29 15:09:03'),(9,'roland.mendel','2013-06-29 15:09:04','2013-06-29 15:09:04'),(10,'paolo.accorti','2013-06-29 15:09:04','2013-06-29 15:09:04'),(11,'julia.tymo','2013-06-29 15:09:06','2013-06-29 15:09:06'),(12,'victoria.ashworth','2013-06-29 15:09:07','2013-06-29 15:09:07'),(13,'laurence.labihan','2013-06-29 15:09:11','2013-06-29 15:09:11'),(14,'maurizio.moroni','2013-06-29 15:09:13','2013-06-29 15:09:13'),(15,'art.braunschweiger','2013-06-29 15:09:15','2013-06-29 15:09:15'),(16,'christina.berglund','2013-06-29 15:09:16','2013-06-29 15:09:16'),(17,'roman.horobets','2013-06-29 15:09:16','2013-06-29 15:09:16'),(18,'john.steel','2013-06-29 15:09:20','2013-06-29 15:09:20'),(19,'nazar.kovalchuk','2013-06-29 15:09:24','2013-06-29 15:09:24'),(20,'anna.trujillo','2013-06-29 15:09:25','2013-06-29 15:09:25'),(21,'vitaliy.parasjuk','2013-06-29 15:09:27','2013-06-29 15:09:27'),(22,'ann.devon','2013-06-29 15:09:28','2013-06-29 15:09:28'),(23,'cristina.solovko','2013-06-29 15:09:30','2013-06-29 15:09:30'),(24,'renate.da.meesne','2013-06-29 15:09:32','2013-06-29 15:09:32'),(25,'peter.franken','2013-06-29 15:09:33','2013-06-29 15:09:33'),(26,'alejandra.camino','2013-06-29 15:09:35','2013-06-29 15:09:35'),(27,'jose.pedro.frayre','2013-06-29 15:09:39','2013-06-29 15:09:39'),(28,'maria.anders','2013-06-29 15:09:41','2013-06-29 15:09:41'),(29,'orest.romanov','2013-06-29 15:09:42','2013-06-29 15:09:42'),(30,'giovanni.rovelli','2013-06-29 15:09:44','2013-06-29 15:09:44'),(31,'olena.burd','2013-06-29 15:09:47','2013-06-29 15:09:47'),(32,'eduardo.saavedra','2013-06-29 15:09:48','2013-06-29 15:09:48'),(33,'horst.kloss','2013-06-29 15:09:50','2013-06-29 15:09:50'),(34,'francua.de.marcos','2013-06-29 15:09:52','2013-06-29 15:09:52'),(35,'orest.venhjyn','2013-06-29 15:09:54','2013-06-29 15:09:54'),(36,'sergio.gutierre','2013-06-29 15:09:56','2013-06-29 15:09:56'),(37,'rene.phillips','2013-06-29 15:09:58','2013-06-29 15:09:58'),(38,'olena.yadoschuk','2013-06-29 15:10:00','2013-06-29 15:10:00'),(39,'liu.wong','2013-06-29 15:10:05','2013-06-29 15:10:05'),(40,'philip.cramer','2013-06-29 15:10:08','2013-06-29 15:10:08'),(41,'paula.wilson','2013-06-29 15:10:14','2013-06-29 15:10:14'),(42,'hanna.moos','2013-06-29 15:10:20','2013-06-29 15:10:20'),(43,'isabel.de.castro','2013-06-29 15:10:30','2013-06-29 15:10:30'),(44,'oksana.shufryn','2013-06-29 15:10:33','2013-06-29 15:10:33'),(45,'jonas.bergulfsen','2013-06-29 15:10:45','2013-06-29 15:10:45'),(46,'zbyszek.piestrzeniewicz','2013-06-29 15:10:50','2013-06-29 15:10:50');
/*!40000 ALTER TABLE `students` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `encrypted_password` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `reset_password_token` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `reset_password_sent_at` datetime DEFAULT NULL,
  `remember_created_at` datetime DEFAULT NULL,
  `sign_in_count` int(11) DEFAULT '0',
  `current_sign_in_at` datetime DEFAULT NULL,
  `last_sign_in_at` datetime DEFAULT NULL,
  `current_sign_in_ip` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `last_sign_in_ip` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `index_users_on_email` (`email`),
  UNIQUE KEY `index_users_on_reset_password_token` (`reset_password_token`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` (`id`, `email`, `encrypted_password`, `reset_password_token`, `reset_password_sent_at`, `remember_created_at`, `sign_in_count`, `current_sign_in_at`, `last_sign_in_at`, `current_sign_in_ip`, `last_sign_in_ip`, `created_at`, `updated_at`) VALUES (1,'pavlo.petryk@gmail.com','$2a$10$azzmuyOzsqp9R71Et51v7eH/D15X5t9uRX9EijVCnStL8yTxtpFjG',NULL,NULL,NULL,1,'2013-06-29 14:28:19','2013-06-29 14:28:19','127.0.0.1','127.0.0.1','2013-06-29 14:28:19','2013-06-29 14:28:19'),(2,'pavlo_petryk@ukr.net','$2a$10$jsCkMQDopYFQcm0q9SCCMOdn7QIOVOj26O.jL/fgd7GyT0WWIN6pO',NULL,NULL,NULL,1,'2013-06-29 15:10:56','2013-06-29 15:10:56','127.0.0.1','127.0.0.1','2013-06-29 15:10:56','2013-06-29 15:10:56');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2013-06-29 18:11:11
