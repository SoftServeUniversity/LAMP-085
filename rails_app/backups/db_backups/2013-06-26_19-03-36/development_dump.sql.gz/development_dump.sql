-- MySQL dump 10.13  Distrib 5.5.31, for debian-linux-gnu (i686)
--
-- Host: localhost    Database: auth_development
-- ------------------------------------------------------
-- Server version	5.5.31-0ubuntu0.12.10.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `homeworks`
--

DROP TABLE IF EXISTS `homeworks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `homeworks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `language` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `homeworks`
--

LOCK TABLES `homeworks` WRITE;
/*!40000 ALTER TABLE `homeworks` DISABLE KEYS */;
INSERT INTO `homeworks` (`id`, `title`, `language`, `created_at`, `updated_at`) VALUES (21,'sales.manager','ruby','2013-06-26 15:50:03','2013-06-26 15:50:03'),(22,'accounting.manager','python','2013-06-26 15:50:05','2013-06-26 15:50:05'),(23,'owner','ruby','2013-06-26 15:50:06','2013-06-26 15:50:06'),(24,'sales.representative','python','2013-06-26 15:50:08','2013-06-26 15:50:08'),(25,'assistant.sales.representative','ruby','2013-06-26 15:50:11','2013-06-26 15:50:11'),(26,'marketing.manager','python','2013-06-26 15:50:11','2013-06-26 15:50:11'),(27,'sales.representative','ruby','2013-06-26 15:50:13','2013-06-26 15:50:13'),(28,'marketing.assistant','python','2013-06-26 15:50:20','2013-06-26 15:50:20'),(29,'owner','python','2013-06-26 15:50:23','2013-06-26 15:50:23'),(30,'marketing.manager','ruby','2013-06-26 15:50:25','2013-06-26 15:50:25'),(31,'accounting.manager','ruby','2013-06-26 15:50:27','2013-06-26 15:50:27'),(32,'sales.manager','python','2013-06-26 15:50:28','2013-06-26 15:50:28'),(33,'sales.associate','python','2013-06-26 15:50:31','2013-06-26 15:50:31'),(34,'sales.agent','ruby','2013-06-26 15:50:36','2013-06-26 15:50:36'),(35,'order.administrator','python','2013-06-26 15:50:43','2013-06-26 15:50:43'),(36,'sales.agent','python','2013-06-26 15:50:45','2013-06-26 15:50:45'),(37,'marketing.assistant','ruby','2013-06-26 15:50:49','2013-06-26 15:50:49'),(38,'sales.associate','ruby','2013-06-26 15:51:06','2013-06-26 15:51:06'),(39,'assistant.sales.agent','python','2013-06-26 15:51:32','2013-06-26 15:51:32'),(40,'assistant.sales.agent','ruby','2013-06-26 15:52:02','2013-06-26 15:52:02');
/*!40000 ALTER TABLE `homeworks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reports`
--

DROP TABLE IF EXISTS `reports`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `reports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `student_id` int(11) DEFAULT NULL,
  `homework_id` int(11) DEFAULT NULL,
  `ratio` float DEFAULT NULL,
  `quality` float DEFAULT NULL,
  `time` float DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=185 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reports`
--

LOCK TABLES `reports` WRITE;
/*!40000 ALTER TABLE `reports` DISABLE KEYS */;
INSERT INTO `reports` (`id`, `student_id`, `homework_id`, `ratio`, `quality`, `time`, `created_at`, `updated_at`) VALUES (93,47,21,100,59.09,2.46,'2013-06-26 15:50:03','2013-06-26 15:50:03'),(94,48,22,100,50,1.01,'2013-06-26 15:50:05','2013-06-26 15:50:05'),(95,47,23,100,59.09,1.58,'2013-06-26 15:50:07','2013-06-26 15:50:07'),(96,49,24,100,50,0.55,'2013-06-26 15:50:08','2013-06-26 15:50:08'),(97,50,24,100,50,0.43,'2013-06-26 15:50:08','2013-06-26 15:50:08'),(98,51,25,100,59.09,1.74,'2013-06-26 15:50:11','2013-06-26 15:50:11'),(99,52,26,100,50,0.43,'2013-06-26 15:50:12','2013-06-26 15:50:12'),(100,53,27,100,59.09,1.7,'2013-06-26 15:50:14','2013-06-26 15:50:14'),(101,54,23,100,59.09,1.58,'2013-06-26 15:50:16','2013-06-26 15:50:16'),(102,55,26,100,50,0.41,'2013-06-26 15:50:16','2013-06-26 15:50:16'),(103,56,26,100,50,0.43,'2013-06-26 15:50:17','2013-06-26 15:50:17'),(104,57,23,100,59.09,1.58,'2013-06-26 15:50:19','2013-06-26 15:50:19'),(105,58,28,100,50,0.43,'2013-06-26 15:50:20','2013-06-26 15:50:20'),(106,51,27,100,59.09,1.6,'2013-06-26 15:50:22','2013-06-26 15:50:22'),(107,52,24,100,50,0.44,'2013-06-26 15:50:22','2013-06-26 15:50:22'),(108,59,29,100,50,0.43,'2013-06-26 15:50:23','2013-06-26 15:50:23'),(109,60,30,100,59.09,1.55,'2013-06-26 15:50:25','2013-06-26 15:50:25'),(110,61,31,100,59.09,1.57,'2013-06-26 15:50:27','2013-06-26 15:50:27'),(111,62,32,100,50,0.42,'2013-06-26 15:50:28','2013-06-26 15:50:28'),(112,63,26,100,50,0.43,'2013-06-26 15:50:29','2013-06-26 15:50:29'),(113,51,31,100,59.09,1.54,'2013-06-26 15:50:31','2013-06-26 15:50:31'),(114,56,33,100,50,0.44,'2013-06-26 15:50:31','2013-06-26 15:50:31'),(115,64,24,100,50,0.43,'2013-06-26 15:50:32','2013-06-26 15:50:32'),(116,52,31,100,59.09,1.65,'2013-06-26 15:50:34','2013-06-26 15:50:34'),(117,65,34,100,59.09,1.63,'2013-06-26 15:50:36','2013-06-26 15:50:36'),(118,66,29,100,50,0.44,'2013-06-26 15:50:37','2013-06-26 15:50:37'),(119,67,23,100,59.09,1.67,'2013-06-26 15:50:39','2013-06-26 15:50:39'),(120,68,32,100,50,0.46,'2013-06-26 15:50:40','2013-06-26 15:50:40'),(121,57,22,100,50,0.47,'2013-06-26 15:50:40','2013-06-26 15:50:40'),(122,69,27,100,59.09,1.58,'2013-06-26 15:50:42','2013-06-26 15:50:42'),(123,50,35,100,50,0.44,'2013-06-26 15:50:43','2013-06-26 15:50:43'),(124,70,24,100,50,0.43,'2013-06-26 15:50:44','2013-06-26 15:50:44'),(125,66,36,100,50,0.44,'2013-06-26 15:50:45','2013-06-26 15:50:45'),(126,71,29,100,50,0.42,'2013-06-26 15:50:45','2013-06-26 15:50:45'),(127,72,23,100,59.09,1.61,'2013-06-26 15:50:47','2013-06-26 15:50:47'),(128,47,37,100,59.09,1.62,'2013-06-26 15:50:49','2013-06-26 15:50:49'),(129,62,22,100,50,0.45,'2013-06-26 15:50:50','2013-06-26 15:50:50'),(130,73,32,100,50,0.44,'2013-06-26 15:50:51','2013-06-26 15:50:51'),(131,53,31,100,59.09,1.56,'2013-06-26 15:50:53','2013-06-26 15:50:53'),(132,74,33,100,50,0.46,'2013-06-26 15:50:53','2013-06-26 15:50:53'),(133,75,24,100,50,0.43,'2013-06-26 15:50:54','2013-06-26 15:50:54'),(134,76,37,100,59.09,1.63,'2013-06-26 15:50:56','2013-06-26 15:50:56'),(135,57,21,100,59.09,1.82,'2013-06-26 15:50:58','2013-06-26 15:50:58'),(136,77,29,100,50,0.44,'2013-06-26 15:50:59','2013-06-26 15:50:59'),(137,52,29,100,50,0.49,'2013-06-26 15:51:00','2013-06-26 15:51:00'),(138,78,26,100,50,0.44,'2013-06-26 15:51:01','2013-06-26 15:51:01'),(139,79,27,100,59.09,1.57,'2013-06-26 15:51:03','2013-06-26 15:51:03'),(140,58,26,100,50,0.43,'2013-06-26 15:51:03','2013-06-26 15:51:03'),(141,80,26,100,50,0.43,'2013-06-26 15:51:04','2013-06-26 15:51:04'),(142,81,38,100,59.09,1.55,'2013-06-26 15:51:06','2013-06-26 15:51:06'),(143,82,37,100,59.09,1.75,'2013-06-26 15:51:08','2013-06-26 15:51:08'),(144,83,38,100,59.09,1.56,'2013-06-26 15:51:10','2013-06-26 15:51:10'),(145,84,21,100,59.09,1.71,'2013-06-26 15:51:12','2013-06-26 15:51:12'),(146,62,28,100,50,0.42,'2013-06-26 15:51:13','2013-06-26 15:51:13'),(147,83,21,100,59.09,1.56,'2013-06-26 15:51:15','2013-06-26 15:51:15'),(148,74,24,100,50,0.42,'2013-06-26 15:51:15','2013-06-26 15:51:15'),(149,85,21,100,59.09,1.55,'2013-06-26 15:51:17','2013-06-26 15:51:17'),(150,84,23,100,59.09,1.6,'2013-06-26 15:51:19','2013-06-26 15:51:19'),(151,86,24,100,50,0.44,'2013-06-26 15:51:20','2013-06-26 15:51:20'),(152,81,34,100,59.09,1.56,'2013-06-26 15:51:22','2013-06-26 15:51:22'),(153,84,27,100,59.09,1.57,'2013-06-26 15:51:23','2013-06-26 15:51:23'),(154,64,33,100,50,0.45,'2013-06-26 15:51:24','2013-06-26 15:51:24'),(155,87,23,100,59.09,1.53,'2013-06-26 15:51:26','2013-06-26 15:51:26'),(156,63,36,100,50,0.42,'2013-06-26 15:51:27','2013-06-26 15:51:27'),(157,85,27,100,59.09,1.53,'2013-06-26 15:51:29','2013-06-26 15:51:29'),(158,57,24,100,50,0.42,'2013-06-26 15:51:29','2013-06-26 15:51:29'),(159,79,31,100,59.09,1.53,'2013-06-26 15:51:31','2013-06-26 15:51:31'),(160,88,39,100,50,0.43,'2013-06-26 15:51:32','2013-06-26 15:51:32'),(161,80,29,100,50,0.43,'2013-06-26 15:51:33','2013-06-26 15:51:33'),(162,49,22,100,50,0.44,'2013-06-26 15:51:33','2013-06-26 15:51:33'),(163,65,37,100,59.09,1.55,'2013-06-26 15:51:35','2013-06-26 15:51:35'),(164,82,30,100,59.09,1.53,'2013-06-26 15:51:37','2013-06-26 15:51:37'),(165,61,21,100,59.09,1.55,'2013-06-26 15:51:39','2013-06-26 15:51:39'),(166,89,21,100,59.09,1.54,'2013-06-26 15:51:41','2013-06-26 15:51:41'),(167,87,31,100,59.09,1.55,'2013-06-26 15:51:42','2013-06-26 15:51:42'),(168,66,35,100,50,0.42,'2013-06-26 15:51:43','2013-06-26 15:51:43'),(169,90,29,100,50,0.43,'2013-06-26 15:51:44','2013-06-26 15:51:44'),(170,72,30,100,59.09,1.54,'2013-06-26 15:51:46','2013-06-26 15:51:46'),(171,57,30,100,59.09,1.58,'2013-06-26 15:51:48','2013-06-26 15:51:48'),(172,47,31,100,59.09,1.53,'2013-06-26 15:51:49','2013-06-26 15:51:49'),(173,70,33,100,50,0.42,'2013-06-26 15:51:50','2013-06-26 15:51:50'),(174,81,37,100,59.09,1.56,'2013-06-26 15:51:52','2013-06-26 15:51:52'),(175,86,29,100,50,0.43,'2013-06-26 15:51:53','2013-06-26 15:51:53'),(176,78,32,100,50,0.43,'2013-06-26 15:51:53','2013-06-26 15:51:53'),(177,91,34,100,59.09,1.54,'2013-06-26 15:51:55','2013-06-26 15:51:55'),(178,85,38,100,59.09,1.55,'2013-06-26 15:51:57','2013-06-26 15:51:57'),(179,70,26,100,50,0.42,'2013-06-26 15:51:58','2013-06-26 15:51:58'),(180,75,29,100,50,0.43,'2013-06-26 15:51:58','2013-06-26 15:51:58'),(181,92,23,100,59.09,1.55,'2013-06-26 15:52:00','2013-06-26 15:52:00'),(182,83,40,100,59.09,1.56,'2013-06-26 15:52:02','2013-06-26 15:52:02'),(183,68,24,100,50,0.43,'2013-06-26 15:52:03','2013-06-26 15:52:03'),(184,87,27,100,59.09,1.54,'2013-06-26 15:52:05','2013-06-26 15:52:05');
/*!40000 ALTER TABLE `reports` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `schema_migrations`
--

DROP TABLE IF EXISTS `schema_migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `schema_migrations` (
  `version` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  UNIQUE KEY `unique_schema_migrations` (`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `schema_migrations`
--

LOCK TABLES `schema_migrations` WRITE;
/*!40000 ALTER TABLE `schema_migrations` DISABLE KEYS */;
INSERT INTO `schema_migrations` (`version`) VALUES ('20130529091028'),('20130529091447'),('20130529091845'),('20130530051123');
/*!40000 ALTER TABLE `schema_migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `students`
--

DROP TABLE IF EXISTS `students`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `students` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=93 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `students`
--

LOCK TABLES `students` WRITE;
/*!40000 ALTER TABLE `students` DISABLE KEYS */;
INSERT INTO `students` (`id`, `name`, `created_at`, `updated_at`) VALUES (47,'matti.karttunen','2013-06-26 15:50:03','2013-06-26 15:50:03'),(48,'thomas.hardy','2013-06-26 15:50:05','2013-06-26 15:50:05'),(49,'helen.bennett','2013-06-26 15:50:07','2013-06-26 15:50:07'),(50,'andriy.padun','2013-06-26 15:50:08','2013-06-26 15:50:08'),(51,'simon.crowther','2013-06-26 15:50:10','2013-06-26 15:50:10'),(52,'pavlo.petryk','2013-06-26 15:50:11','2013-06-26 15:50:11'),(53,'felipe.izquierdo','2013-06-26 15:50:13','2013-06-26 15:50:13'),(54,'liz.nixon','2013-06-26 15:50:15','2013-06-26 15:50:15'),(55,'roland.mendel','2013-06-26 15:50:16','2013-06-26 15:50:16'),(56,'paolo.accorti','2013-06-26 15:50:17','2013-06-26 15:50:17'),(57,'julia.tymo','2013-06-26 15:50:19','2013-06-26 15:50:19'),(58,'victoria.ashworth','2013-06-26 15:50:20','2013-06-26 15:50:20'),(59,'laurence.labihan','2013-06-26 15:50:23','2013-06-26 15:50:23'),(60,'maurizio.moroni','2013-06-26 15:50:25','2013-06-26 15:50:25'),(61,'art.braunschweiger','2013-06-26 15:50:27','2013-06-26 15:50:27'),(62,'christina.berglund','2013-06-26 15:50:28','2013-06-26 15:50:28'),(63,'roman.horobets','2013-06-26 15:50:29','2013-06-26 15:50:29'),(64,'john.steel','2013-06-26 15:50:32','2013-06-26 15:50:32'),(65,'nazar.kovalchuk','2013-06-26 15:50:36','2013-06-26 15:50:36'),(66,'anna.trujillo','2013-06-26 15:50:37','2013-06-26 15:50:37'),(67,'vitaliy.parasjuk','2013-06-26 15:50:39','2013-06-26 15:50:39'),(68,'ann.devon','2013-06-26 15:50:40','2013-06-26 15:50:40'),(69,'cristina.solovko','2013-06-26 15:50:42','2013-06-26 15:50:42'),(70,'renate.da.meesne','2013-06-26 15:50:44','2013-06-26 15:50:44'),(71,'peter.franken','2013-06-26 15:50:45','2013-06-26 15:50:45'),(72,'alejandra.camino','2013-06-26 15:50:47','2013-06-26 15:50:47'),(73,'jose.pedro.frayre','2013-06-26 15:50:51','2013-06-26 15:50:51'),(74,'maria.anders','2013-06-26 15:50:53','2013-06-26 15:50:53'),(75,'orest.romanov','2013-06-26 15:50:54','2013-06-26 15:50:54'),(76,'giovanni.rovelli','2013-06-26 15:50:56','2013-06-26 15:50:56'),(77,'olena.burd','2013-06-26 15:50:59','2013-06-26 15:50:59'),(78,'eduardo.saavedra','2013-06-26 15:51:01','2013-06-26 15:51:01'),(79,'horst.kloss','2013-06-26 15:51:03','2013-06-26 15:51:03'),(80,'francua.de.marcos','2013-06-26 15:51:04','2013-06-26 15:51:04'),(81,'orest.venhjyn','2013-06-26 15:51:06','2013-06-26 15:51:06'),(82,'sergio.gutierre','2013-06-26 15:51:08','2013-06-26 15:51:08'),(83,'rene.phillips','2013-06-26 15:51:10','2013-06-26 15:51:10'),(84,'olena.yadoschuk','2013-06-26 15:51:12','2013-06-26 15:51:12'),(85,'liu.wong','2013-06-26 15:51:17','2013-06-26 15:51:17'),(86,'philip.cramer','2013-06-26 15:51:20','2013-06-26 15:51:20'),(87,'paula.wilson','2013-06-26 15:51:26','2013-06-26 15:51:26'),(88,'hanna.moos','2013-06-26 15:51:32','2013-06-26 15:51:32'),(89,'isabel.de.castro','2013-06-26 15:51:40','2013-06-26 15:51:40'),(90,'oksana.shufryn','2013-06-26 15:51:44','2013-06-26 15:51:44'),(91,'jonas.bergulfsen','2013-06-26 15:51:55','2013-06-26 15:51:55'),(92,'zbyszek.piestrzeniewicz','2013-06-26 15:52:00','2013-06-26 15:52:00');
/*!40000 ALTER TABLE `students` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `encrypted_password` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `reset_password_token` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `reset_password_sent_at` datetime DEFAULT NULL,
  `remember_created_at` datetime DEFAULT NULL,
  `sign_in_count` int(11) DEFAULT '0',
  `current_sign_in_at` datetime DEFAULT NULL,
  `last_sign_in_at` datetime DEFAULT NULL,
  `current_sign_in_ip` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `last_sign_in_ip` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `index_users_on_email` (`email`),
  UNIQUE KEY `index_users_on_reset_password_token` (`reset_password_token`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` (`id`, `email`, `encrypted_password`, `reset_password_token`, `reset_password_sent_at`, `remember_created_at`, `sign_in_count`, `current_sign_in_at`, `last_sign_in_at`, `current_sign_in_ip`, `last_sign_in_ip`, `created_at`, `updated_at`) VALUES (1,'pavlo.petryk@gmail.com','$2a$10$4ZfTiesnBsz0vZkVLu7gAeweF6xQEI/xWQGFnmn8BRUCbAgAZThNG',NULL,NULL,'2013-06-26 12:38:40',4,'2013-06-26 15:21:32','2013-06-26 13:39:58','127.0.0.1','127.0.0.1','2013-06-26 07:38:26','2013-06-26 15:21:32');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2013-06-26 19:03:36
