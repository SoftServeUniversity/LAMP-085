require_relative '../run.rb'
a = Calculator.new
a.summa

describe Calculator do
end
