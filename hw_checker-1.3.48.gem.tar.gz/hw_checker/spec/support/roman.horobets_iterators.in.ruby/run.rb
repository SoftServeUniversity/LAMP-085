class Calculator
 def total 
 	a = 1
 	b = 1
 	return c = a + b
 end
end
