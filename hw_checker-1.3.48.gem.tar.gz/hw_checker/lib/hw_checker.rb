require 'nokogiri'
require 'hw_checker/directory_exist_error'
require 'hw_checker/base'
require 'hw_checker/file_scan'
require 'hw_checker/unarchive'
require 'hw_checker/zip'
require 'hw_checker/test_run_stat'
require 'hw_checker/python_stat'
require 'hw_checker/python_test_run'
require 'hw_checker/ruby_stat'
require 'hw_checker/ruby_test_run'


module HomeWorkChecker
  FILE_TYPES = ['.7z', '.zip'] 
  LANGUAGE_TYPES = {
    '.rb' => [TestRunStat::RubyTestRun, TestRunStat::RubyStat],
    '.py' => [TestRunStat::PythonTestRun, TestRunStat::PythonStat]
  }
end
