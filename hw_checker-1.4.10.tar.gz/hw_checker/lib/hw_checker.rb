require 'nokogiri'
require 'yaml'

require 'hw_checker/directory_exist_error'
require 'hw_checker/directory_format_error'
require 'hw_checker/string'
require 'hw_checker/base'
require 'hw_checker/file_scan'
require 'hw_checker/unarchive'
require 'hw_checker/zip'
require 'hw_checker/archive_result'
require 'hw_checker/code_quality'
require 'hw_checker/test_run'
require 'hw_checker/python_code_quality'
require 'hw_checker/python_test_run'
require 'hw_checker/ruby_code_quality'
require 'hw_checker/ruby_test_run'


module HomeWorkChecker
  def self.configurate
    hwc_home = File.realpath(File.join(File.dirname(__FILE__), '..') )
    config_file = File.join(hwc_home, 'config', 'default.yml')
    hash_conf = YAML.load_file config_file
    archive_types, language_types, module_types = hash_conf['archives'].split(' '), {}, {}
    hash_conf['languages'].each do |key, value|
      language_types[key] = value
      module_types[value] = hash_conf['modules'][value]
    end
    [archive_types, language_types, module_types]
  end

  ARCHIVE_TYPES, LANGUAGE_TYPES, MODULE_TYPES = self.configurate
end
