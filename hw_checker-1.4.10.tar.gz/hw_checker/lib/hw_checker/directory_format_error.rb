module HomeWorkChecker
  class DirectoryFormatError < StandardError; end
end
