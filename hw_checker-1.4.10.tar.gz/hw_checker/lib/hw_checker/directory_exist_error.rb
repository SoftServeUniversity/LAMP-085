module HomeWorkChecker
  class DirectoryExistError < StandardError; end
end
